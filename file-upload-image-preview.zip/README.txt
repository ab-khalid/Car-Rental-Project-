A Pen created at CodePen.io. You can find this one at https://codepen.io/mattsince87/pen/yadZXv.

 A pure Javascript file upload with drop zone (drag & drop) and image preview.

- **No Jquery or Plugins required.**

[Follow me on Twitter](https://twitter.com/mattsince87)
